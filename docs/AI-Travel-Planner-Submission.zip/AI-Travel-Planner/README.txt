AI Travel Planner - Google Startup Buildathon 2026
Founder: Shaik Irfan (shaikirfan24bcs0136@iiitkottayam.ac.in)
Tagline: Your whole trip, planned and booked in minutes.

Contents
- pitch-deck/   Pitch deck PDFs (Buildathon template version and full version)
- demo/         2-minute captioned product demo video (MP4)
- screenshots/  Product screenshots
- source-code/  Full source code (Next.js + TypeScript + PostgreSQL)
                See source-code/README.md to run it and source-code/SETUP.md for API keys.

Live code: https://github.com/magicalnature621-coder/ai-travel-planner

What is real vs demo (MVP)
- Working: sign-up/login, full booking flow (travel only, stay only, or both),
  live Indian Railways trains with real seat availability and fares, day-by-day
  itinerary, PDF e-tickets and stay vouchers, email and WhatsApp confirmations,
  My Trips wallet.
- Demo data for now: flights, buses, hotels and restaurants; payment uses a demo
  checkout; no real tickets are issued.
